import math

def distance(point1, point2):
    """Calculate Euclidean distance between two points."""
    return math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)

def angle_difference(angle1, angle2):
    """Calculate the difference between two angles."""
    return (angle2 - angle1 + 180) % 360 - 180
